﻿using System;
using System.IO;
using System.Collections;
using Tanis.Collections;

namespace Huangbo.AStarPetri.Test
{
    class MainClass
    {

        #region Public Methods

        [STAThread]

        static void Main(string[] args)//主程序
        {
            Huangbo.AStarPetri.AStar astar;
            Huangbo.AStarPetri.AStarNode GoalNode;
            Huangbo.AStarPetri.AStarNode StartNode;

            string filename = "xiong981111";
            string[] initfile = new string[] { "./" + filename + "_init.txt" };
            string[] matrixfile = new string[] { "./" + filename + "_matrix.txt" };

            int[] hmethods = new int[] { 2 };//所用启发函数h
            //h1=max{ei(m)};
            //h2=0;
            //h4=-dep(m);

            bool printScreen = true;//是否向屏幕打印每个扩展节点的信息

            foreach (int hmethod in hmethods)
            {
                astar = new Huangbo.AStarPetri.AStar(initfile[0], matrixfile[0]);
                GoalNode = new Huangbo.AStarPetri.AStarNode(null, null, 0, 0, 0, AStar.GoalM, AStar.GoalMr, 0, 0, 0);
                StartNode = new Huangbo.AStarPetri.AStarNode(null, GoalNode, 0, 0, 0, AStar.StartM, AStar.StartMr, 0, 0, 0);

                Console.WriteLine();
                Console.WriteLine("hmethod={0},filename={1},filename={2},running...", hmethod, initfile[0], matrixfile[0]);

                DateTime startTime = DateTime.Now;//开始时间
                astar.FindPath(StartNode, GoalNode, hmethod, printScreen);
                DateTime endTime = DateTime.Now;//结束时间
                TimeSpan elapsedTime = new TimeSpan(endTime.Ticks - startTime.Ticks);//运行时间

                astar.PrintSolution();	//向屏幕和文件输出		
                astar.SimplePrintSolution(); //向屏幕输出
                Console.WriteLine("运行时间：" + elapsedTime);
            }

            Console.WriteLine("Algorithm finished!");
            Console.ReadLine();
        }

        #endregion
    }
}