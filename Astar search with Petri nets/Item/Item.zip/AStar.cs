﻿using System;
using System.IO;
using System.Collections;
using Tanis.Collections;

namespace Huangbo.AStarPetri
{

    /// <summary>
    /// Base class for pathfinding nodes, it holds no actual information about the map. 
    /// An inherited class must be constructed from this class and all virtual methods must be 
    /// implemented. Note, that calling base() in the overridden methods is not needed.
    /// </summary>

    public class AStarNode : IComparable //Petri网模型可达图中的状态节点
    {
        #region Properties

        public AStarNode Parent//父节点
        {
            set
            {
                FParent = value;
            }
            get
            {
                return FParent;
            }
        }
        private AStarNode FParent;

        public AStarNode GoalNode //目标节点
        {
            set
            {
                FGoalNode = value;
            }
            get
            {
                return FGoalNode;
            }
        }
        private AStarNode FGoalNode;

        public decimal Cost //g值(The accumulative cost of the path until now.)
        {
            set
            {
                FCost = value;
            }
            get
            {
                return FCost;
            }
        }
        private decimal FCost;

        public decimal GoalEstimate //h值(The estimated cost to the goal from here.)
        {//h
            set
            {
                FGoalEstimate = value;
            }
            get
            {
                return FGoalEstimate;
            }
        }
        private decimal FGoalEstimate;

        public decimal TotalCost//f值(The cost plus the estimated cost to the goal from here.)
        {//f
            set
            {
                FTotalCost = value;
            }
            get
            {
                return FTotalCost;
            }
        }
        private decimal FTotalCost;

        public int[] M//节点的标识
        {
            get
            {
                return FM;
            }
        }
        private int[] FM;

        public decimal[] Mr//该标识下所有位置的剩余处理时间
        {
            get
            {
                return FMr;
            }
        }
        private decimal[] FMr;

        public int TFireFrom//产生本标识所实施的变迁
        {
            get
            {
                return FTFireFrom;
            }
            set
            {
                FTFireFrom = value;
            }
        }
        private int FTFireFrom;

        public int[] EnabledTransitions//本标识中可实施变迁的集合
        {
            get
            {
                return FEnabledTransitions;
            }
            set
            {
                Array.Copy(value, FEnabledTransitions, value.Length);
            }
        }
        private int[] FEnabledTransitions;

        public int MarkingDepth//标识深度
        {
            get
            {
                return FMarkingDepth;
            }
            set
            {
                FMarkingDepth = value;
            }
        }
        private int FMarkingDepth;

        public decimal Delt//从父标识到某变迁实施得到本标识所用时间
        {//从父marking到transition实施得到本marking所需时间
            set
            {
                FDelt = value;
            }
            get
            {
                return FDelt;
            }
        }
        private decimal FDelt;

        //private int[] u = new int[AStar.nt];//控制向量u
        private decimal delt = 0;//变迁变为可实施所需时间
        
        //通过变迁的发射放入输出库所中的托肯必须等待一定时间后才可利用，并且该时间等于该库所的时延
        // M(k)- 和 Mr(k)- 分别表示：变迁发射前，那刻 "系统的标识" 和 "剩余处理时间向量"
        // M(k)+ 和 Mr(k)+ 分别表示：变迁发射后，输入托肯已移走但输出托肯还未加入时 "系统的标识" 和 "剩余处理时间向量"
        private int[] MF = new int[AStar.np];//标识状态M(k)-
        private int[] MZ = new int[AStar.np];//标识状态M(k)+
        private decimal[] MrF = new decimal[AStar.np];//标识状态Mr(k)-
        private decimal[] MrZ = new decimal[AStar.np];//标识状态Mr(k)+	  

        #endregion

        #region Constructors

        //AStarNode(父节点, 目标节点, g值, h值, f值, 节点的标志, 该标识下所有位置的剩余处理时间, 产生本标识所实施的变迁, 标志的深度, 从父标识到变迁实施得到本标识所用时间)
        public AStarNode(AStarNode AParent, AStarNode AGoalNode, decimal ACost, decimal AGoalEstimate, decimal ATotalCost, int[] AM, decimal[] AMr, int ATFireFrom, int AMarkingDepth, decimal ADelt)
        {
            FParent = AParent;
            FGoalNode = AGoalNode;
            FCost = ACost;
            FGoalEstimate = AGoalEstimate;
            FTotalCost = ATotalCost;
            FM = new int[AStar.np];
            Array.Copy(AM, FM, AM.Length);
            FMr = new decimal[AStar.np];
            Array.Copy(AMr, FMr, AMr.Length);
            FTFireFrom = ATFireFrom;
            FEnabledTransitions = new int[AStar.nt];
            FMarkingDepth = AMarkingDepth;
            FDelt = ADelt;
        }
        #endregion

        #region Public Methods

        public bool IsGoal()
        {//判断本节点的M和Mr是否与GoalNode一致
            if (IsSameStatePlusMr(FGoalNode) == false)//判断M和Mr是否相等
                return false;
            for (int i = 0; i < this.Mr.Length; ++i)
                if (this.Mr[i] != FGoalNode.Mr[i])
                    return false;
            return true;
        }

        public virtual bool IsSameState(AStarNode ANode)//判断某节点的标识M是否和本节点一致
        {//只判断M
            if (ANode == null)
                return false;
            if (FM.Length != ANode.FM.Length)
                return false;
            for (int i = 0; i < FM.Length; ++i)
                if (FM[i] != ANode.FM[i])
                    return false;
            return true;
        }

        public virtual bool IsSameStatePlusMr(AStarNode ANode)//判断某节点的M和Mr是否和本节点一致
        {//判断M和Mr
            if (ANode == null)
                return false;
            if (FM.Length != ANode.FM.Length)
                return false;
            for (int i = 0; i < FM.Length; ++i)
                if (FM[i] != ANode.FM[i])
                    return false;
            for (int i = 0; i < FMr.Length; ++i)
                if (FMr[i] != ANode.FMr[i])
                    return false;
            return true;
        }

        public virtual decimal Calculate(int method)//Calculates the estimated cost for the remaining trip to the goal.
        //h1=max{ei(m)};
        //h2=0;
        //h4=-dep(m);
        {

            //h=max{ei(m)} where ei(m) is the sum of operation times of those remaining operation for all jobs
			//which are planned to be processed on the ith machine when the current system state is represented 
			//by the marking m
            if (method == 1)
            {
                //xiong98
                const int ResNum = 3; //三个资源库所
                int[] MachineTime = new int[ResNum];
                for (int i = 0; i < MachineTime.Length; ++i)
                {
                    MachineTime[i] = 0;
                }

                int[,] RST =
                {
                    {2,3,4},{0,3,4},{0,3,4},{0,0,4},{0,0,4},{0,0,0},{0,0,0},
                    {2,2,4},{2,2,0},{2,2,0},{0,2,0},{0,2,0},{0,0,0},{0,0,0},
                    {3,3,5},{0,3,5},{0,3,5},{0,3,0},{0,3,0},{0,0,0},{0,0,0},
                    {3,3,4},{3,0,4},{3,0,4},{3,0,0},{3,0,0},{0,0,0},{0,0,0},
                    {0,0,0},{0,0,0},{0,0,0}
                };

                for (int n = 0; n < AStar.np; ++n)
                {
                    if (MF[n] != 0)
                    {
                        for (int x = 0; x < ResNum; ++x)
                        {
                            MachineTime[x] += MF[n] * RST[n, x];
                        }
                    }
                }

                //加Mr
                for (int n = 0; n < AStar.np; ++n)
                {
                    if (MrF[n] != 0)
                    {
                        if (n==1||n==10||n==15||n==26)
                            MachineTime[0] += (int)MrF[n];
                        else if (n == 3 || n == 12 || n == 19 || n == 22)
                            MachineTime[1] += (int)MrF[n];
                        else if (n == 5 || n == 8 || n == 18 || n == 24)
                            MachineTime[2] += (int)MrF[n];
                    }
                }

                //h=max{ei(m)}
                int max = 0;
                for (int i = 0; i < MachineTime.Length; ++i)
                {
                    if (max < MachineTime[i])
                    {
                        max = MachineTime[i];
                    }
                }
                return max;
            }

            if (method == 2)
            {
                return 0;
            }

            if (method == 4)
            {
                return (-(FMarkingDepth + 1));
            }

            return 0;
        }

        public virtual void FindEnabledTransitions()//寻找当前标识（FM[i]）下可实施的变迁，并对EnabledTransitions赋值（1：可以实施，0：不能实施）
        {
            int e;
            for (int j = 0; j < AStar.nt; ++j)
            {
                e = 1;
                for (int i = 0; i < AStar.np; ++i)
                {
                    if (AStar.LMINUS[i, j] != 0 && FM[i] < AStar.LMINUS[i, j]) //变迁可以实施的条件：当前标志的库所大于变迁所需的输入库所（ M(p) > I(p, t) ）
                    {
                        e = 0;
                        continue;
                    }
                }
                EnabledTransitions[j] = e; //EnabledTransitions = new int[AStar.nt];
            }
        }

        public virtual void GetSuccessors(ArrayList ASuccessors, int hmethod) //获得当前节点的所有子节点，并添加到列表中
        {
            //寻找当前标识下可实施的变迁
            FindEnabledTransitions();

            for (int i = 0; i < FEnabledTransitions.Length; ++i)
            {
                if (FEnabledTransitions[i] == 1) //变迁可以实施
                {
                    //程序选择哪个变迁发射取决于系统所采用的派遣规则

                    /*//计算控制向量u（u = new int[AStar.nt]）
                    //如果j = j*，则u = 1，否则u = 0
                    for (int m = 0; m < u.Length; ++m)
                    {
                        if (m == i)
                            u[m] = 1;
                        else
                            u[m] = 0;
                    }*/

                    //计算 delt=max{Mrz}
                    delt = 0;
                    for (int x = 0; x < AStar.np; ++x)
                    {
                        if (AStar.LMINUS[x, i] == 1)
                        {
                            //该标识下所有位置的剩余处理时间的最大值
                            if (delt < FMr[x])
                                delt = FMr[x];
                        }
                    }

                    //从变迁的输入库所中移去相应的托肯
                    //M(k)+ = M(k)- - LMINUS*u(k) , M(k)+ 和M(k)- 分别表示托肯移走前后的系统标识
                    for (int n = 0; n < AStar.np; ++n)
                    {
                        if (AStar.LMINUS[n, i] != 0)
                            MZ[n] = FM[n] - AStar.LMINUS[n, i]; //MZ：标识状态M(k)+
                        else
                            MZ[n] = FM[n];
                    }

                    //向变迁的所有输出库所中添加相应托肯
                    //M(k+1)- = M(k)+ + LPLUS*u(k)
                    for (int n = 0; n < AStar.np; ++n)
                    {
                        if (AStar.LPLUS[n, i] != 0)
                            MF[n] = MZ[n] + AStar.LPLUS[n, i];
                        else
                            MF[n] = MZ[n];
                    }

                    //在剩余处理时间向量中逐个元素地减去delt，若值小于0则赋值为0
                    //计算 Mr(k)+z = Mr(k)-z - delt(k)z
                    for (int n = 0; n < AStar.np; ++n)
                    {
                        MrZ[n] = FMr[n] - delt;
                        if (MrZ[n] < 0)
                            MrZ[n] = 0;
                    }

                    //向变迁的所有输出库所的剩余操作时间中加入相应时间
                    //Mr(k+1)-z = Mr(k)+z + t(k)z
                    for (int n = 0; n < AStar.np; ++n)
                    {
                        if (AStar.LPLUS[n, i] == 1)
                            MrF[n] = MrZ[n] + AStar.t[n]; //t：操作时间
                        else
                            MrF[n] = MrZ[n];
                    }

                    decimal g = FCost + delt;
                    decimal h = Calculate(hmethod);
                    decimal f = g + h;

                    AStarNode NewNode = new AStarNode(this, GoalNode, g, h, f, MF, MrF, i, FMarkingDepth + 1, delt);
                    //AStarNode(父节点, 目标节点, g值, h值, f值, 节点的标志, 该标识下所有位置的剩余处理时间, 产生本标识所实施的变迁, 标志的深度, 从父标识到变迁实施得到本标识所用时间)
                    ASuccessors.Add(NewNode);
                }
            }//for循环结束

        }

        public virtual void PrintNodeInfo(int loop) //打印当前节点的信息
        {
            Console.Write("loop:{0}\tf:{1}\tg:{2}\th:{3}\ttFireFrom:{4}\tDepth:{5} ", loop, FTotalCost, FCost, FGoalEstimate, FTFireFrom + 1, FMarkingDepth);
            Console.Write("tEnabled:");
            for (int n = 0; n < EnabledTransitions.Length; ++n)
            {
                if (EnabledTransitions[n] == 1)
                    Console.Write("{0} ", n + 1);
            }
            Console.Write("\tM:");
            for (int i = 0; i < FM.Length; ++i)//输出M中为1的palce
            {
                if (FM[i] == 1)
                    Console.Write("{0} ", i + 1);
                if (FM[i] > 1)
                    Console.Write("{0}({1})", i + 1, FM[i]);
            }
            Console.Write("\tMr:");
            for (int i = 0; i < FMr.Length; ++i)
            {
                if (FMr[i] != 0)
                    Console.Write("[{0}]:{1} ", i + 1, FMr[i]);
            }
            Console.WriteLine();
        }

        #endregion

        #region Overridden Methods

        public override bool Equals(object obj)
        {
            return IsSameState((AStarNode)obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        #endregion

        #region IComparable Members

        public int CompareTo(object obj)
        {
            return (TotalCost.CompareTo(((AStarNode)obj).TotalCost));
        }

        #endregion
    }


    public sealed class AStar //Petri网模型运行所需的全局属性和行为
    {
        #region Private Fields
        private AStarNode FStartNode;//起始节点
        private AStarNode FGoalNode;//目标节点
        private Heap FOpenList;//Open列表
        private Heap FClosedList;//Close列表
        private ArrayList FSuccessors;//子节点列表
        private ArrayList FExpandedList;//已扩展节点列表
        private ArrayList FSolution;//结果方案列表
        private int FNExpandedNode;//已扩展节点数
        #endregion

        #region Properties
        public struct Cost
        {
            public decimal cost1;
            public decimal cost2;
        };
        public static decimal[] t;//各库所的操作时间
        //public static Cost[] t;//各库所的操作代价
        public static int[,] LPLUS;//关联矩阵L+
        public static int[,] LMINUS;//关联矩阵L-

        public static int np;//Petri网中位置数(含资源)
        public static int nt;//Petri网中变迁数
        public static int nrs;//Petri网中资源位置数

        public static int[] StartM;//开始节点的标识向量
        public static int[] GoalM;//目标节点的标识向量
        public static decimal[] StartMr;//开始节点的剩余处理时间向量
        public static decimal[] GoalMr;//目标节点的剩余处理时间向量

        public ArrayList Solution//结果方案列表
        {
            get
            {
                return FSolution;
            }
        }
        public int NExpandedNode//已扩展节点数
        {
            get
            {
                return FNExpandedNode;
            }
            set
            {
                FNExpandedNode = value;
            }
        }

        private ArrayList ChildrenInOpenList = new ArrayList();//ArrayList 可动态增加的数组

        #endregion

        #region Constructors

        public AStar(string initfile, string matrixfile)//构造函数
        {
            FOpenList = new Heap();
            FClosedList = new Heap();
            FSuccessors = new ArrayList();
            FSolution = new ArrayList();
            FExpandedList = new ArrayList();

            Read_initfile(initfile);
            Read_matrixfile(matrixfile);

            Console.WriteLine("Petri网中位置数(含资源)：" + np);
            Console.WriteLine("Petri网中变迁数：" + nt);
            Console.WriteLine("Petri网中资源位置数：" + nrs);
            Console.WriteLine("初始marking：");
            for (int i = 0; i < np; i++)
            {
                Console.Write(StartM[i] + " ");
            }
            Console.WriteLine();
            Console.WriteLine("目标marking：");
            for (int i = 0; i < np; i++)
            {
                Console.Write(GoalM[i] + " ");
            }
            Console.WriteLine();
            Console.WriteLine("伴随矩阵L+：");
            for (int i = 0; i < np; ++i)
            {
                for (int j = 0; j < nt; ++j)
                {
                    Console.Write(LPLUS[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("伴随矩阵L-：");
            for (int i = 0; i < np; ++i)
            {
                for (int j = 0; j < nt; ++j)
                {
                    Console.Write(LMINUS[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();


            StartMr = new decimal[np];
            GoalMr = new decimal[np];
            for (int i = 0; i < np; ++i)
            {
                StartMr[i] = 0;
                GoalMr[i] = 0;
            }

        }

        #endregion

        #region Private Methods

        private static void Read_initfile(string filename)
        {
            StreamReader SR;
            try
            {
                SR = File.OpenText(filename);
            }
            catch
            {
                Console.Write(filename + " open failed!");
                return;
            }
            string S;
            string[] SubS;

            //init文件的第一行
            {
                S = SR.ReadLine();
                SubS = S.Split(new char[] { ' ' });//string[]不指定大小就可以使用

                //Petri网中位置数(含资源)
                np = SubS.Length;

                //初始marking
                StartM = new int[np];
                for (int i = 0; i < SubS.Length; ++i)
                {
                    StartM[i] = Convert.ToInt32(SubS[i]);
                }
            }

            //init文件的第二行
            {
                S = SR.ReadLine();
                SubS = S.Split(new char[] { ' ' });

                //Petri网中资源位置数
                nrs = 0;
                /*t = new Cost[np]; //各位置的操作代价
                for (int i = 0; i < SubS.Length; ++i)
                {
                    if(SubS[i].Length != 1)
                    {
                        t[i].cost1 = Convert.ToInt32(SubS[i].Split(new char[] { ',' })[0]);
                        t[i].cost2 = Convert.ToInt32(SubS[i].Split(new char[] { ',' })[1]);
                        nrs++;
                    }
                    else
                    {
                        t[i].cost1 = 0;
                        t[i].cost2 = 0;
                    }
                }*/
                t = new decimal[np]; //各位置的操作时间
                for (int i = 0; i < SubS.Length; ++i)
                {
                    if (Convert.ToInt32(SubS[i]) != 0)
                    {
                        t[i] = Convert.ToInt32(SubS[i]);
                        nrs++;
                    }
                }
            }

            //init文件的第三行
            {
                S = SR.ReadLine();
                SubS = S.Split(new char[] { ' ' });

                //目标marking
                GoalM = new int[np];
                for (int i = 0; i < SubS.Length; ++i)
                {
                    GoalM[i] = Convert.ToInt32(SubS[i]);
                }
            }

            SR.Close();
            return;
        }

        private static void Read_matrixfile(string filename)
        {
            StreamReader SR;
            try
            {
                SR = File.OpenText(filename);
            }
            catch
            {
                Console.Write(filename + " open failed!");
                return;
            }
            string S;

            //Petri网中变迁数
            nt = 0;

            S = SR.ReadLine();
            while (S != null)
            {
                ++nt;
                S = SR.ReadLine();
            }
            SR.Close();

            StreamReader SRR;
            try
            {
                SRR = File.OpenText(filename);
            }
            catch
            {
                Console.Write(filename + " open failed!");
                return;
            }

            //临时矩阵 nt * np
            int[,] temp = new int[nt, np];

            S = SRR.ReadLine();
            string[] SubS;
            int n = 0;
            while (S != null)
            {
                SubS = S.Split(new char[] { ' ' });
                for (int i = 0 ,j = 0; i < SubS.Length && j< np; ++i)
                {
                    if (SubS[i].Equals("1"))
                    {
                        temp[n, j] = 1;
                        ++j;
                    }
                    else if (SubS[i].Equals("0"))
                    {
                        temp[n, j] = 0;
                        ++j;
                    }
                    else if (SubS[i].Equals("-1"))
                    {
                        temp[n, j] = -1;
                        ++j;
                    }
                }
                S = SRR.ReadLine();
                n++;
            }

            /*//matri.txt输入矩阵
            for (int i = 0; i<nt; ++i)
            {
                for (int j = 0; j < np; ++j)
                {
                    Console.Write(temp[i, j] + " ");
                }
                Console.WriteLine();
            }*/

            //伴随矩阵L+
            LPLUS = new int[np, nt];

            //伴随矩阵L-
            LMINUS = new int[np, nt];

            for (int i = 0; i < nt; ++i)
            {
                for (int j = 0; j < np; ++j)
                {
                    if (temp[i, j] == 1)
                    {
                        LPLUS[j, i] = 1;
                    }
                    else
                    {
                        LPLUS[j, i] = 0;
                    }

                    if (temp[i, j] == -1)
                    {
                        LMINUS[j, i] = 1;
                    }
                    else
                    {
                        LMINUS[j, i] = 0;
                    }
                }
            }

            SRR.Close();
            return;
        }

        // HList按FTotalCost排好序了，将Node插入相同FTotalCost的第一个位置
        private int SortAdd(Heap HList, AStarNode Node)//将节点插入到相同FTotalCost值的第一个位置
        {
            int position = 0;
            for (int i = 0; i < HList.Count; ++i)
            {
                AStarNode LNode = (AStarNode)HList[i];
                if (LNode.TotalCost >= Node.TotalCost)
                    break;
                else
                    ++position;
            }
            if (position == HList.Count)
                HList.Add(Node);//加到末尾处
            else
                HList.Insert(position, Node);
            return position;
        }

        private void PrintNodeList(object ANodeList)//输出某列表中所有节点的信息
        {
            Console.WriteLine("\nNode list:");
            int i = 0;
            foreach (AStarNode n in (ANodeList as IEnumerable))
            {
                Console.Write("{0})\t", i + 1);
                i++;
                n.PrintNodeInfo(0);
            }
            Console.WriteLine("=============================================================");
        }

        #endregion

        #region Public Methods

        public void SimplePrintSolution()//有重载，用于输出open节点数
        {
            Console.WriteLine("The number of markings in open:{0}", FOpenList.Count);
        }

        //向屏幕输出，并写文件result.txt,有重载
        public void PrintSolution()
        {
            PrintNodeList(FSolution);//向屏幕输出FSolution			
            Console.WriteLine("The number of expanded markings:{0}\t{1}", NExpandedNode, FExpandedList.Count);

            Console.WriteLine("File writing...");
            FileStream ostrm;
            StreamWriter writer;
            TextWriter oldOut = Console.Out;
            try
            {
                ostrm = new FileStream("./result.txt", FileMode.OpenOrCreate, FileAccess.Write);
                writer = new StreamWriter(ostrm);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Cannot open result.txt for writing.");
                return;
            }
            Console.SetOut(writer);
            PrintNodeList(FSolution);//向文件输出FSolution	


            Console.WriteLine("*************FExpandedList***********");
            Console.WriteLine("The number of expanded markings:{0}", NExpandedNode);//
            PrintNodeList(FExpandedList);//向文件输出FExpandedList

            Console.WriteLine("*************OpenList***********");
            PrintNodeList(FOpenList);//向文件输出FOpenList


            Console.SetOut(oldOut);
            writer.Close();
            ostrm.Close();
            Console.WriteLine("File(A* result.txt) writing complete.");

        }

        public void FindPath(AStarNode AStartNode, AStarNode AGoalNode, int hmethod, bool printScreen)
        {
            //hmethod:所用启发函数h
            //h1=max{ei(m)};
            //h2=0;
            //h4=-dep(m);

            //printScreen:是否向屏幕打印每个扩展节点的信息

            FStartNode = AStartNode;
            FGoalNode = AGoalNode;

            FOpenList.Clear();
            FClosedList.Clear();
            FSuccessors.Clear();
            FSolution.Clear();
            FExpandedList.Clear();
            NExpandedNode = 0;

            int loop = 0;
            FOpenList.Add(FStartNode);

            while (FOpenList.Count >= 0)
            {
                loop++;

                if (FOpenList.Count == 0)
                {
                    Console.WriteLine("*******Failure!********");
                    break;
                }

                //OPEN列表中的第一个节点
                AStarNode NodeCurrent = (AStarNode)FOpenList[0];
                FOpenList.Remove(FOpenList[0]);	//除去要扩展的节点

                //如果当前节点是目的节点，则回溯构造出路径
                if (NodeCurrent.IsGoal())
                {
                    while (NodeCurrent != null)
                    {
                        FSolution.Insert(0, NodeCurrent);
                        NodeCurrent = NodeCurrent.Parent;
                    }

                    break; //程序正常退出
                }

                //把当前节点的所有子节点加入到FSuccessors
                FSuccessors.Clear(); 
                NodeCurrent.GetSuccessors(FSuccessors, hmethod);

                if (printScreen == true)
                    NodeCurrent.PrintNodeInfo(loop);//打印当前节点的信息

                foreach (AStarNode NodeSuccessor in FSuccessors)
                {

                    // ----------------------------若生成的节点已在OPEN列表中----------------------------
                    AStarNode NodeOpen = null;
                    foreach (AStarNode a in FOpenList)
                    {
                        if (a.IsSameStatePlusMr(NodeSuccessor))
                        {
                            NodeOpen = a; //扩展出的子节点已经在OPEN列表中
                            break;
                        }
                    }
                    if ((NodeOpen != null) && (NodeSuccessor.Cost < NodeOpen.Cost)) //节点已经在OPEN列表中，但新途径生成的代价更小
                    {
                        FOpenList.Remove(NodeOpen);
                        SortAdd(FOpenList, NodeSuccessor);
                        continue;
                    }


                    // ----------------------------若生成的节点已在CLOSE列表中----------------------------
                    AStarNode NodeClosed = null;
                    foreach (AStarNode b in FClosedList)
                    {
                        if (b.IsSameStatePlusMr(NodeSuccessor))
                        {
                            NodeClosed = b; //扩展出的子节点已经在CLOSE列表中
                            break;
                        }
                    }
                    if ((NodeClosed != null) && (NodeSuccessor.Cost < NodeClosed.Cost)) //节点已经在CLOSE列表中，但新途径生成的代价更小
                    {
                        ChildrenInOpenList.Clear();
                        foreach (AStarNode n in FOpenList)
                        {
                            if (n.Parent.IsSameStatePlusMr(NodeClosed)) //该CLOSE列表中的节点为OPEN列表中节点的父节点  （Equals 的默认实现仅支持引用相等，但派生类可重写此方法以支持值相等）
                                ChildrenInOpenList.Add(n);
                        }
                        for (int a = 0; a < ChildrenInOpenList.Count; ++a)
                        {
                            FOpenList.Remove(ChildrenInOpenList[a]);
                        }
                        FClosedList.Remove(NodeClosed);
                        SortAdd(FOpenList, NodeSuccessor);
                        continue;
                    }


                    // ---------------------若生成的节点既不在OPEN列表中，也不再CLOSE列表中--------------------
                    if ((NodeOpen == null) && (NodeClosed == null))
                    {
                        SortAdd(FOpenList, NodeSuccessor);
                    }

                } //foreach (AStarNode NodeSuccessor in FSuccessors)结束

                SortAdd(FClosedList, NodeCurrent);

                FExpandedList.Add(NodeCurrent);
                if (FSuccessors.Count > 0) //若当前节点没有子节点，则当前节点为死锁
                {
                    //NExpandedNode没加入死锁节点，所以比FExpandedList.Count可能要小 (运行发现和FExpandedList.Count一样)
                    ++NExpandedNode;//已扩展节点数
                }

            }//while (FOpenList.Count > 0) 结束

            /*AStarNode FinalMarking = (AStarNode)FSolution[FSolution.Count - 1];

            double[] result = new double[4];
            result[0] = (double)FinalMarking.TotalCost;//最后结果的cost
            result[1] = (double)FExpandedList.Count;//最后EXPANDED表的长度
            result[2] = (double)FOpenList.Count;//最后OPEN表的长度
            result[3] = (double)FClosedList.Count;//最后CLOSE表的长度

            result[1] = NExpandedNode;
            Console.WriteLine("result:", result);
            for (int i = 0; i < 4; ++i)
            {
                Console.Write(result[i] + " ");
            }
            return result*/
         
        }//FindPath

        #endregion
    }
}